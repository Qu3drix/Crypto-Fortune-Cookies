import React, { useEffect, useState } from 'react'
import fortunes from '../data/fortunes.json'
import clsx from 'clsx'

const COINGECKO_API = 'https://api.coingecko.com/api/v3/simple/price'
const SUPPORTED = [
  { id: 'bitcoin', symbol: 'BTC' },
  { id: 'ethereum', symbol: 'ETH' },
  { id: 'solana', symbol: 'SOL' },
  { id: 'cardano', symbol: 'ADA' },
  { id: 'dogecoin', symbol: 'DOGE' }
]

export default function CryptoFortune() {
  const [selected, setSelected] = useState(SUPPORTED[0].id)
  const [price, setPrice] = useState(null)
  const [loading, setLoading] = useState(false)
  const [fortune, setFortune] = useState('Click "Open Cookie" to reveal your crypto fortune!')
  const [shake, setShake] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchPrice(selected)
  }, [selected])

  async function fetchPrice(coinId) {
    setLoading(true)
    setError(null)
    try {
      const q = `${COINGECKO_API}?ids=${coinId}&vs_currencies=usd&include_24hr_change=true`
      const res = await fetch(q)
      if (!res.ok) throw new Error('API error')
      const data = await res.json()
      setPrice(data[coinId])
    } catch (e) {
      setError('Failed to fetch price — try again later.')
      setPrice(null)
    } finally {
      setLoading(false)
    }
  }

  function openCookie() {
    setShake(true)
    setTimeout(() => setShake(false), 800)
    const pick = fortunes[Math.floor(Math.random() * fortunes.length)]
    setFortune(pick)
  }

  function shareText() {
    const coin = SUPPORTED.find(c => c.id === selected)
    const priceStr = price ? `$${price.usd.toLocaleString()} (${price.usd_24h_change?.toFixed(2)}% 24h)` : 'price unknown'
    return `🔮 Crypto Fortune for ${coin.symbol}: ${fortune} — Current: ${priceStr}`
  }

  async function tryShare() {
    const text = shareText()
    if (navigator.share) {
      try { await navigator.share({ text }) } catch (e) { /* ignore */ }
    } else {
      await navigator.clipboard.writeText(text)
      alert('Copied fortune to clipboard!')
    }
  }

  return (
    <div className="max-w-xl w-full bg-white shadow-2xl rounded-2xl p-6">
      <h2 className="text-2xl font-semibold mb-2">Crypto Fortune Cookie</h2>
      <p className="text-sm text-slate-500 mb-4">Pick a coin and open a fortune cookie — powered by CoinGecko.</p>

      <div className="flex gap-2 mb-4">
        <select
          aria-label="Select coin"
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
          className="flex-1 p-2 border rounded"
        >
          {SUPPORTED.map(c => (
            <option key={c.id} value={c.id}>{c.symbol}</option>
          ))}
        </select>
        <button
          onClick={() => fetchPrice(selected)}
          className="px-4 py-2 rounded bg-slate-100 hover:bg-slate-200"
        >Refresh</button>
      </div>

      <div className="mb-4">
        <div className="text-sm text-slate-500">Current price</div>
        <div className="mt-1">
          {loading ? (
            <div className="italic">Loading...</div>
          ) : error ? (
            <div className="text-red-500">{error}</div>
          ) : price ? (
            <div className="text-lg font-mono">${price.usd.toLocaleString()} <span className={clsx('ml-3 text-sm', price.usd_24h_change >= 0 ? 'text-green-600' : 'text-red-600')}>{price.usd_24h_change?.toFixed(2)}%</span></div>
          ) : (
            <div className="text-sm text-slate-400">No data</div>
          )}
        </div>
      </div>

      <div className="mb-4">
        <div className={clsx('p-4 rounded-xl border', shake ? 'animate-[shake_0.8s]' : '')}>
          <div className="text-slate-600">{fortune}</div>
        </div>
      </div>

      <div className="flex gap-2">
        <button onClick={openCookie} className="flex-1 py-2 rounded bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-medium shadow">Open Cookie</button>
        <button onClick={tryShare} className="px-4 py-2 rounded border">Share</button>
      </div>

      <style>{`@keyframes shake { 10%, 90% { transform: translate3d(-1px, 0, 0); } 20%, 80% { transform: translate3d(2px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-4px, 0, 0); } 40%, 60% { transform: translate3d(4px, 0, 0); } }`}</style>
    </div>
  )
}
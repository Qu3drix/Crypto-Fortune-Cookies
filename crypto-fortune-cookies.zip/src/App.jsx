import React from 'react'
import CryptoFortune from './components/CryptoFortune'

export default function App() {
  return (
    <div className="min-h-screen py-12 px-4 flex items-center justify-center">
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        <div>
          <h1 className="text-4xl font-extrabold mb-4">Crypto Fortune Cookies</h1>
          <p className="text-slate-600 mb-6">A tiny playful app that mixes real-time crypto prices with motivational crypto "fortunes" — perfect for demos, README screenshots, and GitHub Pages deployments.</p>
          <ul className="list-disc pl-5 text-slate-700">
            <li>Fetches price data from CoinGecko</li>
            <li>Random fortunes stored locally</li>
            <li>Share or copy fortunes</li>
          </ul>
        </div>

        <div className="flex items-center justify-center">
          <CryptoFortune />
        </div>
      </div>
    </div>
  )
}